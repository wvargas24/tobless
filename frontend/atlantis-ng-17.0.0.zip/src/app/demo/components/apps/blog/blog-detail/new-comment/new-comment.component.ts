import { Component } from '@angular/core';

@Component({
    selector: 'app-new-comment',
    templateUrl: './new-comment.component.html'
})
export class NewCommentComponent { }
