import { Component } from '@angular/core';

@Component({
    templateUrl: './mail.app.component.html',
})
export class MailAppComponent {}
